/**
 * Created by aijiechen on 12/5/16.
 */
public interface Move {
    void move();
}
