/**
 * Created by aijiechen on 11/20/16.
 */
abstract class Agent implements Move{
    public int x;
    public int y;

    public Agent(int x, int y)
    {
        this.x = x;
        this.y = y;
    }


}



